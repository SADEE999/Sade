// Supabase browser configuration. Publishable/anon key only; never add a service_role or secret key here.
window.STORE_CONFIG = {
  SUPABASE_URL: "https://cpmzjplfqggmgeotmtcd.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_z0kmWe85ybkmBg7bzEtyKA_kMH6WGXW",
  STORE_NAME: "SADEE XDIMA",
  SUPPORT_EMAIL: "hello@example.com",
  WHATSAPP_NUMBER: "94768472404",
  EZCASH_NUMBER: "94760625028",
  CURRENCY: "LKR"
};
